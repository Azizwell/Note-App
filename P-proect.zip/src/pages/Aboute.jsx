import React from "react";

export default function Aboute() {
  return (
    <div className="jumbotron">
      <div className="container">
        <h1 className="display-4">React приложения</h1>
        <p className="lead">
          Версия приложения <strong>1.0.42</strong>
        </p>
      </div>
    </div>
  );
}
