import React, { useRef } from "react";
import { CSSTransition, TransitionGroup } from "react-transition-group";

export default function Notes({ notes, onRemove }) {
  const nodeRef = useRef(null);
  return (
    <div>
      <TransitionGroup component={"ul"} className="list-group">
        {notes.map((note) => {
          return (
            <CSSTransition
              key={note.id}
              classNames={"note"}
              timeout={800}
              nodeRef={nodeRef}
            >
              <li ref={nodeRef} className="list-group-item note">
                <div>
                  <strong>{note.title}</strong>
                  <small>{note.date}</small>
                </div>
                <button
                  onClick={() => onRemove(note.id)}
                  className="btn btn-outline-danger btn-sm"
                >
                  &times;
                </button>
              </li>
            </CSSTransition>
          );
        })}
      </TransitionGroup>
    </div>
  );
}
